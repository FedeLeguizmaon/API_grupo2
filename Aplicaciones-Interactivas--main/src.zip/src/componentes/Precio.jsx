const Precio = function({Valor,onClick}){
    return(
        <p onClick={onClick}> {Valor}</p>

    )
}


export default Precio;