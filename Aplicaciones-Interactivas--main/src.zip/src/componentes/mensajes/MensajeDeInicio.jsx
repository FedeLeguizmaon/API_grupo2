import React from "react";
const mensajeDeInicio=()=>{
    return(
        <>
        <h1>Has inciado sesion correctamente</h1>
        </>
    )
}

export default mensajeDeInicio;