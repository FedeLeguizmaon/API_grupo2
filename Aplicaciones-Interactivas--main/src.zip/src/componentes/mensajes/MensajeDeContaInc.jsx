import React from "react";
const MensajeDeContaInc=()=>{
    return(
        <>
        <h4>
            El usuario/contraseña ingresados son incorrectos
        </h4>
        </>
    )
}
export default MensajeDeContaInc;