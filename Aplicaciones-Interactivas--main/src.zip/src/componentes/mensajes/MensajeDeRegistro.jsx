import React from "react";


const MensajeDeRegistro =() =>{
    
    return(
        <>
        <h1>El usuario que intenta agregar ya existe</h1>
        </>
    )
}

export default MensajeDeRegistro;