import React from "react";

const HistorialDePedidos=()=>{
    return(
        <>
        <h1>ACA HACER EL FETCH CON EL GET PEDIDOS CUANDO TENGAMOS LO DE PEDIDOS HECHO</h1>
        </>
    )
}
export default  HistorialDePedidos;